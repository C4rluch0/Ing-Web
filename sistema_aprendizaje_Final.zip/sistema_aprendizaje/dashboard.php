<?php
// dashboard.php
require_once 'config.php';

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$usuario = new Usuario();
$temaManager = new TemaManager();
$premioManager = new PremioManager();

$perfil = $usuario->obtenerPerfil($_SESSION['user_id']);
$temas = $temaManager->obtenerTemas();
$premios_disponibles = $premioManager->verificarPremioUsuario($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Aprendizaje</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>@<?php echo $_SESSION['user_apodo']; ?></p>
                <div class="puntos">
                    <span class="puntos-numero"><?php echo $_SESSION['user_puntos']; ?></span> puntos
                </div>
                <p>Nivel: <?php echo ucfirst($_SESSION['user_nivel']); ?></p>
            </div>
            
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php">🎮 Jugar</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="mis_premios.php">🏆 Mis Premios</a>
                <a href="subir_avatar.php">👤 Avatar</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <header>
                <h1>Dashboard</h1>
            </header>
            
            <!-- Premios disponibles -->
            <?php if (!empty($premios_disponibles)): ?>
            <div class="alert alert-success">
                <h3>¡Tienes premios disponibles!</h3>
                <div class="premios-grid">
                    <?php foreach ($premios_disponibles as $premio): ?>
                    <div class="premio-card">
                        <img src="premios/<?php echo $premio['imagen']; ?>" alt="<?php echo $premio['nombre']; ?>">
                        <h4><?php echo $premio['nombre']; ?></h4>
                        <p><?php echo $premio['descripcion']; ?></p>
                        <form method="POST" action="reclamar_premio.php">
                            <input type="hidden" name="premio_id" value="<?php echo $premio['id']; ?>">
                            <button type="submit" class="btn btn-small">Reclamar</button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Estadísticas rápidas -->
            <section class="stats-section">
                <h2>Estadísticas</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3><?php echo $_SESSION['user_puntos']; ?></h3>
                        <p>Puntos Totales</p>
                    </div>
                    <div class="stat-card">
                        <h3><?php echo count($premioManager->obtenerPremiosUsuario($_SESSION['user_id'])); ?></h3>
                        <p>Premios Obtenidos</p>
                    </div>
                    <div class="stat-card">
                        <h3><?php echo count($temas); ?></h3>
                        <p>Temas Disponibles</p>
                    </div>
                </div>
            </section>
        </div>
    </div>
</body>
</html>