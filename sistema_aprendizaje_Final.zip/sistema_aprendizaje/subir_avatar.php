<?php
// subir_avatar.php
require_once 'config.php';

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$usuario = new Usuario();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    if ($usuario->actualizarAvatar($_SESSION['user_id'], $_FILES['avatar'])) {
        $message = '<div class="success">Avatar actualizado correctamente.</div>';
    } else {
        $message = '<div class="error">Error al subir el avatar. Asegúrate de que sea una imagen válida (JPG, PNG, GIF) y no pese más de 5MB.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Avatar - Sistema de Aprendizaje</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>@<?php echo $_SESSION['user_apodo']; ?></p>
                <div class="puntos">
                    <span class="puntos-numero"><?php echo $_SESSION['user_puntos']; ?></span> puntos
                </div>
                <p>Nivel: <?php echo ucfirst($_SESSION['user_nivel']); ?></p>
            </div>
            
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php">🎮 Jugar</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="mis_premios.php">🏆 Mis Premios</a>
                <a href="subir_avatar.php">👤 Avatar</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Cambiar Avatar</h1>
            </header>
            
            <div class="avatar-container">
                <?php echo $message; ?>
                
                <div class="current-avatar">
                    <h3>Avatar Actual:</h3>
                    <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar Actual" class="avatar-large">
                </div>
                
                <form method="POST" action="" enctype="multipart/form-data" class="avatar-form">
                    <div class="form-group">
                        <label for="avatar">Seleccionar nueva imagen:</label>
                        <input type="file" id="avatar" name="avatar" accept="image/*" required>
                        <small>Formatos permitidos: JPG, PNG, GIF. Tamaño máximo: 5MB</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Subir Avatar</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
                </form>
                
                <div class="avatar-gallery">
                    <h3>Avatares Predeterminados:</h3>
                    <div class="gallery-grid">
                        <?php
                        $default_avatars = [
                            'avatar.png', 
                            'avatar1.png', 
                            'avatar2.png', 
                            'avatar3.png', 
                            'avatar4.png',
                            'avatar5.png'  
                        ]; 

                        foreach ($default_avatars as $avatar):
                            if (file_exists('avatars/' . $avatar)):
                        ?>
                        <div class="avatar-item">
                            <img src="avatars/<?php echo $avatar; ?>" alt="Avatar" class="avatar-small">
                            <form method="POST" action="cambiar_avatar_default.php" style="display:inline;">
                                <input type="hidden" name="avatar" value="<?php echo $avatar; ?>">
                                <button type="submit" class="btn btn-small">Seleccionar</button>
                            </form>
                        </div>
                        <?php endif; endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>