<?php
// eliminar_pregunta.php - CORREGIDO
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    // Redirigir si no hay sesión
    header('Location: login.php');
    exit();
}

$pregunta_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$pregunta_id) {
    // Si no hay ID, redirigir con un error
    header('Location: mis_preguntas.php?error=no_id');
    exit();
}

$temaManager = new TemaManager();

// Llamar al método corregido en TemaManager
$resultado = $temaManager->eliminarPregunta($pregunta_id);

if ($resultado) {
    // Éxito
    header('Location: mis_preguntas.php?mensaje=pregunta_eliminada');
} else {
    // Error
    header('Location: mis_preguntas.php?error=error_al_eliminar');
}
exit();
?>