<?php
// cambiar_avatar_default.php
require_once 'config.php';

// 1. Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$redirect_url = 'subir_avatar.php';

// 2. Verificar la solicitud POST y el campo 'avatar'
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['avatar'])) {
    $new_avatar_filename = basename($_POST['avatar']); // Limpieza básica para seguridad
    $usuario = new Usuario();

    // Lista de avatares predeterminados.
    // ESTA LISTA DEBE COINCIDIR EXACTAMENTE con la lista en subir_avatar.php
    $default_avatars = ['avatar.png', 'avatar1.png', 'avatar2.png', 'avatar3.png', 'avatar4.png', 'avatar5.png']; 
    
    // Si ampliaste la lista, asegúrate de incluir todos los nombres aquí:
    // $default_avatars = ['default.png', 'avatar1.png', 'avatar2.png', 'avatar3.png', 'avatar4.png', 'avatar5.png'];
    
    // 3. Validar el nombre del avatar
    if (in_array($new_avatar_filename, $default_avatars) && file_exists('avatars/' . $new_avatar_filename)) {
        
        // 4. Intentar actualizar el avatar (Asume que el método existe en la clase Usuario)
        if ($usuario->actualizarAvatarDefault($_SESSION['user_id'], $new_avatar_filename)) {
            // Éxito: Guardar mensaje en sesión
            $_SESSION['message'] = '<div class="alert alert-success">✅ Avatar predeterminado seleccionado correctamente.</div>';
        } else {
            // Error en DB
            $_SESSION['message'] = '<div class="alert alert-error">❌ Error al guardar el avatar en la base de datos.</div>';
        }
    } else {
        // Error de validación
        $_SESSION['message'] = '<div class="alert alert-error">❌ El archivo de avatar seleccionado no es válido.</div>';
    }
} else {
    // Solicitud no POST o campo faltante
    $_SESSION['message'] = '<div class="alert alert-error">❌ Solicitud no válida.</div>';
}

// 5. Redirigir de vuelta a subir_avatar.php
header('Location: ' . $redirect_url);
exit();