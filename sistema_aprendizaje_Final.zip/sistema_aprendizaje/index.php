<?php
// index.php
require_once 'config.php';

// Redirigir al login si no está autenticado, o al dashboard si sí lo está
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
} else {
    header('Location: login.php');
}
exit();
?>