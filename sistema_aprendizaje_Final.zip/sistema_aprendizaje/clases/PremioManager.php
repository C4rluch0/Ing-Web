<?php
// clases/PremioManager.php
class PremioManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function crearPremio($data, $imagen) {
        try {
            // Subir imagen
            if ($imagen['error'] == UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($imagen['name'], PATHINFO_EXTENSION));
                $newFileName = uniqid() . '_premio.' . $ext;
                $uploadPath = PREMIOS_DIR . $newFileName;
                
                if (!move_uploaded_file($imagen['tmp_name'], $uploadPath)) {
                    return false;
                }
            } else {
                $newFileName = 'default_premio.png';
            }
            
            $stmt = $this->db->prepare("
                INSERT INTO premios (nombre, descripcion, imagen, nivel_requerido, puntos_requeridos, activo, fecha_creacion)
                VALUES (?, ?, ?, ?, ?, 1, NOW())
            ");
            
            $stmt->execute([
                Sanitizer::cleanInput($data['nombre']),
                Sanitizer::cleanInput($data['descripcion']),
                $newFileName,
                $data['nivel_requerido'],
                $data['puntos_requeridos']
            ]);
            
            return $this->db->lastInsertId();
        } catch(PDOException $e) {
            Sanitizer::logError("Crear premio error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerPremios($nivel = null) {
        try {
            $sql = "SELECT * FROM premios WHERE activo = 1";
            $params = [];
            
            if ($nivel) {
                $sql .= " AND nivel_requerido = ?";
                $params[] = $nivel;
            }
            
            $sql .= " ORDER BY puntos_requeridos ASC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener premios error: " . $e->getMessage());
            return [];
        }
    }
    
    public function obtenerPremio($id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM premios WHERE id = ? AND activo = 1");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener premio error: " . $e->getMessage());
            return false;
        }
    }
    
    public function actualizarPremio($id, $data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE premios 
                SET nombre = ?, descripcion = ?, nivel_requerido = ?, puntos_requeridos = ? 
                WHERE id = ?
            ");
            
            return $stmt->execute([
                Sanitizer::cleanInput($data['nombre']),
                Sanitizer::cleanInput($data['descripcion']),
                $data['nivel_requerido'],
                $data['puntos_requeridos'],
                $id
            ]);
        } catch(PDOException $e) {
            Sanitizer::logError("Actualizar premio error: " . $e->getMessage());
            return false;
        }
    }
    
    public function eliminarPremio($id) {
        try {
            $stmt = $this->db->prepare("UPDATE premios SET activo = 0 WHERE id = ?");
            return $stmt->execute([$id]);
        } catch(PDOException $e) {
            Sanitizer::logError("Eliminar premio error: " . $e->getMessage());
            return false;
        }
    }
    
    public function verificarPremioUsuario($usuario_id) {
        try {
            // Obtener datos del usuario
            $stmt = $this->db->prepare("SELECT puntos, nivel_actual FROM usuarios WHERE id = ?");
            $stmt->execute([$usuario_id]);
            $usuario = $stmt->fetch();
            
            // Buscar premios que el usuario puede reclamar
            $stmt = $this->db->prepare("
                SELECT p.* 
                FROM premios p
                LEFT JOIN usuario_premios up ON p.id = up.premio_id AND up.usuario_id = ?
                WHERE p.activo = 1 
                AND p.nivel_requerido = ?
                AND p.puntos_requeridos <= ?
                AND up.id IS NULL
            ");
            
            $stmt->execute([
                $usuario_id,
                $usuario['nivel_actual'],
                $usuario['puntos']
            ]);
            
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            Sanitizer::logError("Verificar premio usuario error: " . $e->getMessage());
            return [];
        }
    }
    
    public function asignarPremio($usuario_id, $premio_id) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO usuario_premios (usuario_id, premio_id, fecha_obtencion)
                VALUES (?, ?, NOW())
            ");
            
            return $stmt->execute([$usuario_id, $premio_id]);
        } catch(PDOException $e) {
            Sanitizer::logError("Asignar premio error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerPremiosUsuario($usuario_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, up.fecha_obtencion
                FROM usuario_premios up
                JOIN premios p ON up.premio_id = p.id
                WHERE up.usuario_id = ?
                ORDER BY up.fecha_obtencion DESC
            ");
            
            $stmt->execute([$usuario_id]);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener premios usuario error: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerTodosLosPremios() {
        try {
            $stmt = $this->db->prepare("
                SELECT *
                FROM premios
                WHERE activo = 1
                ORDER BY puntos_requeridos ASC
            ");
            
            $stmt->execute();
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener todos los premios error: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerPremioPorId($premio_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT *
                FROM premios
                WHERE id = ? AND activo = 1
            ");
            
            $stmt->execute([$premio_id]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener premio por ID error: " . $e->getMessage());
            return false;
        }
    }
}
?>