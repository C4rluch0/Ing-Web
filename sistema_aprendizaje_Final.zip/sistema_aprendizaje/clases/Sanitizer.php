<?php
// clases/Sanitizer.php
class Sanitizer {
    
    public static function cleanInput($data) {
        if (empty($data)) {
            return '';
        }
        
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        return $data;
    }
    
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }
    
    public static function validatePassword($password) {
        return strlen($password) >= 6;
    }
    
    public static function validateImage($file) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (!isset($file['name']) || empty($file['name'])) {
            return false;
        }
        
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed)) {
            return false;
        }
        
        if ($file['size'] > 5000000) { // 5MB max
            return false;
        }
        
        return true;
    }
}
?>