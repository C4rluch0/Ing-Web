<?php
// clases/ErrorHandlerInterface.php
interface ErrorHandlerInterface {
    public static function logError($error);
    public static function showError($error, $type = 'user');
    public static function validateRequired($data, $fields);
}
?>