<?php
// clases/TemaManager.php
class TemaManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function crearTema($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO temas (nombre, descripcion, nivel, activo, fecha_creacion)
                VALUES (?, ?, ?, 1, NOW())
            ");
            
            $stmt->execute([
                Sanitizer::cleanInput($data['nombre']),
                Sanitizer::cleanInput($data['descripcion']),
                Sanitizer::cleanInput($data['nivel'])
            ]);
            
            return $this->db->lastInsertId();
        } catch(PDOException $e) {
            Sanitizer::logError("Crear tema error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerTemas($nivel = null) {
        try {
            $sql = "SELECT * FROM temas WHERE activo = 1";
            $params = [];
            
            if ($nivel) {
                $sql .= " AND nivel = ?";
                $params[] = $nivel;
            }
            
            $sql .= " ORDER BY fecha_creacion DESC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener temas error: " . $e->getMessage());
            return [];
        }
    }
    
    public function obtenerTema($id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM temas WHERE id = ? AND activo = 1");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener tema error: " . $e->getMessage());
            return false;
        }
    }
    
    public function actualizarTema($id, $data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE temas 
                SET nombre = ?, descripcion = ?, nivel = ? 
                WHERE id = ?
            ");
            
            return $stmt->execute([
                Sanitizer::cleanInput($data['nombre']),
                Sanitizer::cleanInput($data['descripcion']),
                Sanitizer::cleanInput($data['nivel']),
                $id
            ]);
        } catch(PDOException $e) {
            Sanitizer::logError("Actualizar tema error: " . $e->getMessage());
            return false;
        }
    }
    
    public function eliminarTema($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM temas WHERE id = ?");
            return $stmt->execute([$id]);
        } catch(PDOException $e) {
            Sanitizer::logError("Eliminar tema error: " . $e->getMessage());
            return false;
        }
    }
    
    // ==================== MÉTODOS PARA PREGUNTAS ====================
    
    public function crearPregunta($data) {
        try {
            // Serializar opciones a JSON
            $opciones_json = json_encode($data['opciones']);
            
            $sql = "INSERT INTO preguntas (tema_id, pregunta, tipo, opciones, respuesta_correcta, puntos, usuario_id, fecha_creacion) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $stmt = $this->db->prepare($sql);
            
            // Verifica que tenemos session iniciada
            if (!isset($_SESSION['user_id'])) {
                throw new Exception("Usuario no autenticado");
            }
            
            $stmt->execute([
                $data['tema_id'],
                $data['pregunta'],
                $data['tipo'],
                $opciones_json,
                $data['respuesta_correcta'],
                $data['puntos'],
                $_SESSION['user_id']
            ]);
            
            return $this->db->lastInsertId();
            
        } catch (PDOException $e) {
            error_log("Error al crear pregunta: " . $e->getMessage());
            return false;
        } catch (Exception $e) {
            error_log("Error de sesión: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerPregunta($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, t.nombre as tema_nombre 
                FROM preguntas p 
                JOIN temas t ON p.tema_id = t.id 
                WHERE p.id = ?
            ");
            $stmt->execute([$id]);
            $pregunta = $stmt->fetch();
            
            if ($pregunta && !empty($pregunta['opciones'])) {
                $opciones = json_decode($pregunta['opciones'], true);
                // Asegurar que 'opciones' es un array después de decodificar
                $pregunta['opciones'] = is_array($opciones) ? $opciones : [];
            } else {
                $pregunta['opciones'] = [];
            }
            
            return $pregunta;
        } catch(PDOException $e) {
            error_log("Obtener pregunta error: " . $e->getMessage());
            return false;
        }
    }
    
    public function actualizarPregunta($id, $data) {
        try {
            // Asegurar que $data['opciones'] sea un array o vacío antes de serializar
            $opciones = is_array($data['opciones']) ? $data['opciones'] : [];
            $opciones_json = json_encode($opciones); // Serializar opciones a JSON
            
            $sql = "UPDATE preguntas SET 
                    tema_id = ?, 
                    pregunta = ?, 
                    tipo = ?, 
                    opciones = ?, 
                    respuesta_correcta = ?, 
                    puntos = ? 
                    WHERE id = ?";
            
            $stmt = $this->db->prepare($sql);
            
            return $stmt->execute([
                $data['tema_id'],
                $data['pregunta'],
                $data['tipo'],
                $opciones_json,
                $data['respuesta_correcta'],
                $data['puntos'],
                $id
            ]);
            
        } catch (PDOException $e) {
            error_log("Error al actualizar pregunta: " . $e->getMessage());
            return false;
        }
    }
    
    public function eliminarPregunta($id) {
        try {
            // Solo se usa el borrado lógico para mantener historial
            $stmt = $this->db->prepare("DELETE FROM preguntas WHERE id = ?");
            return $stmt->execute([$id]);
            
        } catch(PDOException $e) {
            error_log("Eliminar pregunta error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerPreguntas($tema_id) {
        try {
            $sql = "SELECT p.*, t.nombre as tema_nombre 
                    FROM preguntas p 
                    JOIN temas t ON p.tema_id = t.id 
                    WHERE p.activo = 1";
            $params = [];
            
            if ($tema_id) {
                $sql .= " AND p.tema_id = ?";
                $params[] = $tema_id;
            }
            
            $sql .= " ORDER BY RAND()";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            $preguntas = $stmt->fetchAll();
            
            // Decodificar JSON de opciones
            foreach ($preguntas as &$pregunta) {
                $opciones = json_decode($pregunta['opciones'], true);
                $pregunta['opciones'] = is_array($opciones) ? $opciones : [];
            }
            
            return $preguntas;
        } catch(PDOException $e) {
            Sanitizer::logError("Obtener preguntas error: " . $e->getMessage());
            return [];
        }
    }
    
    public function verificarRespuesta($pregunta_id, $respuesta) {
        try {
            $stmt = $this->db->prepare("SELECT respuesta_correcta, puntos FROM preguntas WHERE id = ?");
            $stmt->execute([$pregunta_id]);
            $pregunta = $stmt->fetch();
            
            if ($pregunta && $pregunta['respuesta_correcta'] == $respuesta) {
                return ['correcta' => true, 'puntos' => $pregunta['puntos']];
            }
            
            return ['correcta' => false, 'puntos' => 0];
        } catch(PDOException $e) {
            Sanitizer::logError("Verificar respuesta error: " . $e->getMessage());
            return ['correcta' => false, 'puntos' => 0];
        }
    }

    public function obtenerPreguntasUsuario($usuario_id, $tema_id = null) {
        try {
            $sql = "SELECT p.*, t.nombre as tema_nombre 
                    FROM preguntas p 
                    JOIN temas t ON p.tema_id = t.id 
                    WHERE p.usuario_id = ? AND p.activo = 1";
            
            $params = [$usuario_id];
            
            if ($tema_id) {
                $sql .= " AND p.tema_id = ?";
                $params[] = $tema_id;
            }
            
            $sql .= " ORDER BY p.fecha_creacion DESC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            $preguntas = $stmt->fetchAll();
            
            // Decodificar JSON de opciones
            foreach ($preguntas as &$pregunta) {
                if (!empty($pregunta['opciones'])) {
                    $opciones = json_decode($pregunta['opciones'], true);
                    $pregunta['opciones'] = is_array($opciones) ? $opciones : [];
                } else {
                    $pregunta['opciones'] = [];
                }
            }
            
            return $preguntas;
            
        } catch(PDOException $e) {
            error_log("Obtener preguntas usuario error: " . $e->getMessage());
            return [];
        }
    }

    public function puedeEditarPregunta($pregunta_id, $usuario_id) {
        try {
            $stmt = $this->db->prepare("SELECT usuario_id FROM preguntas WHERE id = ?");
            $stmt->execute([$pregunta_id]);
            $pregunta = $stmt->fetch();
            
            // Solo el creador puede editar
            return ($pregunta && $pregunta['usuario_id'] == $usuario_id);
        } catch(PDOException $e) {
            error_log("Error verificar edición: " . $e->getMessage());
            return false;
        }
    }
    
    // Método para verificar si una pregunta existe
    public function existePregunta($id) {
        try {
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM preguntas WHERE id = ?");
            $stmt->execute([$id]);
            $result = $stmt->fetch();
            return $result && $result['count'] > 0;
        } catch(PDOException $e) {
            error_log("Error verificar existencia pregunta: " . $e->getMessage());
            return false;
        }
    }
    
    // Método para obtener estadísticas de preguntas del usuario
    public function obtenerEstadisticasPreguntas($usuario_id) {
        try {
            $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN nivel = 'basico' THEN 1 ELSE 0 END) as basicas,
                    SUM(CASE WHEN nivel = 'intermedio' THEN 1 ELSE 0 END) as intermedias,
                    SUM(CASE WHEN nivel = 'avanzado' THEN 1 ELSE 0 END) as avanzadas,
                    SUM(CASE WHEN nivel = 'experto' THEN 1 ELSE 0 END) as expertas,
                    SUM(CASE WHEN tipo = 'multiple' THEN 1 ELSE 0 END) as multiples,
                    SUM(CASE WHEN tipo = 'verdadero_falso' THEN 1 ELSE 0 END) as verdadero_falso
                    FROM preguntas 
                    WHERE usuario_id = ? AND activo = 1";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$usuario_id]);
            
            return $stmt->fetch();
        } catch(PDOException $e) {
            error_log("Error obtener estadísticas preguntas: " . $e->getMessage());
            return ['total' => 0, 'basicas' => 0, 'intermedias' => 0, 'avanzadas' => 0, 'expertas' => 0, 'multiples' => 0, 'verdadero_falso' => 0];
        }
    }
}
?>