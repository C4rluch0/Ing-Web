<?php
// clases/QRManager.php

// Cargar autoload de Composer
require_once __DIR__ . '/../vendor/autoload.php';

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;

class QRManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    private function getTemaManager() {
        // Asumiendo que TemaManager está en el directorio 'clases/'
        require_once __DIR__ . '/TemaManager.php'; 
        return new TemaManager();
    }

    /**
     * Crea un set completo a partir de un tema, obteniendo todas sus preguntas activas.
     */
    public function crearSetDesdeTema($usuario_id, $tema_id, $nombre_set, $descripcion_set) {
        $temaManager = $this->getTemaManager();
        $tema = $temaManager->obtenerTema($tema_id);

        if (!$tema) {
            return ['error' => 'Tema no encontrado.'];
        }

        // 1. Obtener todas las preguntas del tema
        $preguntas = $temaManager->obtenerPreguntas($tema_id);
        
        // Obtener solo los IDs
        $pregunta_ids = array_column($preguntas, 'id');

        if (empty($pregunta_ids)) {
            return ['error' => 'No hay preguntas activas en este tema para crear un set.'];
        }

        // 2. Crear el set utilizando la función existente
        $data = [
            'nombre' => $nombre_set,
            'descripcion' => $descripcion_set,
            'tema_id' => $tema_id,
            'nivel' => $tema['nivel'], // Obtener nivel del tema
            'preguntas' => $pregunta_ids
        ];

        // Se reusa crearSetPreguntas
        return $this->crearSetPreguntas($usuario_id, $data);
    }
    
    public function crearSetPreguntas($usuario_id, $data) {
        try {
            // Validar datos
            if (empty($data['nombre']) || empty($data['tema_id'])) {
                throw new Exception("Nombre y tema son requeridos");
            }
            
            // Generar código único
            $codigo_qr = 'SET_' . $usuario_id . '_' . time() . '_' . rand(1000, 9999);
            
            $stmt = $this->db->prepare("
                INSERT INTO sets_preguntas (usuario_id, nombre, descripcion, tema_id, nivel, codigo_qr, fecha_creacion, activo)
                VALUES (?, ?, ?, ?, ?, ?, NOW(), 1)
            ");
            
            $stmt->execute([
                $usuario_id,
                htmlspecialchars($data['nombre'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($data['descripcion'] ?? '', ENT_QUOTES, 'UTF-8'),
                intval($data['tema_id']),
                $data['nivel'] ?? 'basico',
                $codigo_qr
            ]);
            
            $set_id = $this->db->lastInsertId();
            
            // Agregar preguntas al set
            if (!empty($data['preguntas']) && is_array($data['preguntas'])) {
                foreach ($data['preguntas'] as $pregunta_id) {
                    $this->agregarPreguntaSet($set_id, intval($pregunta_id));
                }
            }
            
            // Generar imagen QR
            $qrImagePath = $this->generarQR($set_id, $codigo_qr);
            
            return [
                'set_id' => $set_id, 
                'codigo_qr' => $codigo_qr, 
                'qr_image' => $qrImagePath,
                'url' => BASE_URL . 'play_set.php?code=' . urlencode($codigo_qr)
            ];
            
        } catch(PDOException $e) {
            error_log("Crear set preguntas error: " . $e->getMessage());
            return ['error' => 'Error en la base de datos: ' . $e->getMessage()];
        } catch(Exception $e) {
            error_log("Crear set error: " . $e->getMessage());
            return ['error' => $e->getMessage()];
        }
    }
    
    private function agregarPreguntaSet($set_id, $pregunta_id) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO set_preguntas_rel (set_id, pregunta_id)
                VALUES (?, ?)
            ");
            
            return $stmt->execute([$set_id, $pregunta_id]);
        } catch(PDOException $e) {
            error_log("Agregar pregunta set error: " . $e->getMessage());
            return false;
        }
    }
    
    public function generarQR($set_id, $codigo_qr) {
        try {
            $url = BASE_URL . 'play_set.php?code=' . urlencode($codigo_qr);
            
            // Crear QR Code
            $qrCode = QrCode::create($url)
                ->setEncoding(new Encoding('UTF-8'))
                ->setSize(300)
                ->setMargin(10)
                ->setForegroundColor(new Color(0, 0, 0))
                ->setBackgroundColor(new Color(255, 255, 255));
            
            $writer = new PngWriter();
            $result = $writer->write($qrCode);
            
            // Guardar imagen
            $qrDir = __DIR__ . '/../qrcodes/';
            if (!is_dir($qrDir)) {
                mkdir($qrDir, 0777, true);
            }
            
            $filename = 'set_' . $set_id . '.png';
            $filepath = $qrDir . $filename;
            
            // Guardar la imagen
            $result->saveToFile($filepath);
            
            return 'qrcodes/' . $filename;
            
        } catch(Exception $e) {
            error_log("Generar QR error: " . $e->getMessage());
            
            // Fallback: generar QR con Google Charts API
            return $this->generarQRGoogle($codigo_qr);
        }
    }
    
    private function generarQRGoogle($codigo_qr) {
        $url = BASE_URL . 'play_set.php?code=' . urlencode($codigo_qr);
        $googleQRUrl = "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=" . urlencode($url) . "&choe=UTF-8";
        
        return $googleQRUrl;
    }
    
    public function obtenerSetPorCodigo($codigo) {
        try {
            $stmt = $this->db->prepare("
                SELECT s.*, u.nombre as creador_nombre, t.nombre as tema_nombre
                FROM sets_preguntas s
                JOIN usuarios u ON s.usuario_id = u.id
                JOIN temas t ON s.tema_id = t.id
                WHERE s.codigo_qr = ? AND s.activo = 1
            ");
            
            $stmt->execute([$codigo]);
            $set = $stmt->fetch();
            
            if ($set) {
                // Obtener preguntas del set
                $stmt = $this->db->prepare("
                    SELECT p.* FROM preguntas p
                    JOIN set_preguntas_rel spr ON p.id = spr.pregunta_id
                    WHERE spr.set_id = ? AND p.activo = 1
                ");
                
                $stmt->execute([$set['id']]);
                $preguntas = $stmt->fetchAll();
                
                // Decodificar opciones si existen
                foreach ($preguntas as &$pregunta) {
                    if (!empty($pregunta['opciones'])) {
                        $opciones = json_decode($pregunta['opciones'], true);
                        $pregunta['opciones'] = is_array($opciones) ? $opciones : [];
                    } else {
                        $pregunta['opciones'] = [];
                    }
                }
                
                $set['preguntas'] = $preguntas;
            }
            
            return $set;
        } catch(PDOException $e) {
            error_log("Obtener set por código error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerSetsUsuario($usuario_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT s.*, t.nombre as tema_nombre, 
                       (SELECT COUNT(*) FROM set_preguntas_rel WHERE set_id = s.id) as total_preguntas
                FROM sets_preguntas s
                JOIN temas t ON s.tema_id = t.id
                WHERE s.usuario_id = ? AND s.activo = 1
                ORDER BY s.fecha_creacion DESC
            ");
            
            $stmt->execute([$usuario_id]);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            error_log("Obtener sets usuario error: " . $e->getMessage());
            return [];
        }
    }
    
    public function mostrarQR($codigo_qr, $qr_image) {
        echo "<div class='qr-container'>";
        echo "<h3>Código QR Generado</h3>";
        
        if (strpos($qr_image, 'http') === 0) {
            // Es una URL de Google Charts
            echo "<img src='$qr_image' alt='Código QR' style='max-width: 300px;'>";
        } else {
            // Es una imagen local
            echo "<img src='$qr_image' alt='Código QR' style='max-width: 300px;'>";
        }
        
        echo "<p><strong>Código:</strong> <code>$codigo_qr</code></p>";
        echo "<p><strong>URL para compartir:</strong> " . BASE_URL . "play_set.php?code=" . urlencode($codigo_qr) . "</p>";
        echo "<p><button onclick='copiarCodigo(\"$codigo_qr\")' class='btn btn-small'>Copiar Código</button></p>";
        echo "</div>";
        
        echo "<script>
        function copiarCodigo(codigo) {
            navigator.clipboard.writeText(codigo).then(function() {
                alert('Código copiado al portapapeles: ' + codigo);
            }, function(err) {
                alert('Error al copiar: ' + err);
            });
        }
        </script>";
    }
}
?>