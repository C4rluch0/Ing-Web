<?php
// clases/Usuario.php
class Usuario {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function login($email, $password) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nombre'] = $user['nombre'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_apodo'] = $user['apodo'];
                $_SESSION['user_avatar'] = $user['avatar'];
                $_SESSION['user_puntos'] = $user['puntos'];
                $_SESSION['user_nivel'] = $user['nivel_actual'];
                
                return true;
            }
            return false;
        } catch(PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
    
    public function registrar($data) {
        try {
            // Validar campos requeridos
            $required = ['nombre', 'email', 'password', 'apodo'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return ["El campo $field es requerido"];
                }
            }
            
            // Validar email
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                return ["Email no válido"];
            }
            
            // Validar contraseña
            if (strlen($data['password']) < 6) {
                return ["La contraseña debe tener al menos 6 caracteres"];
            }
            
            // Verificar si el email ya existe
            $stmt = $this->db->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$data['email']]);
            
            if ($stmt->rowCount() > 0) {
                return ["El email ya está registrado"];
            }
            
            // Verificar confirmación de contraseña
            if ($data['password'] !== $data['confirm_password']) {
                return ["Las contraseñas no coinciden"];
            }
            
            // Insertar nuevo usuario
            $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("
                INSERT INTO usuarios (nombre, email, password, apodo, avatar, puntos, nivel_actual, fecha_registro)
                VALUES (?, ?, ?, ?, 'avatar.png', 0, 'basico', NOW())
            ");
            
            $stmt->execute([
                htmlspecialchars($data['nombre'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8'),
                $hashed_password,
                htmlspecialchars($data['apodo'], ENT_QUOTES, 'UTF-8')
            ]);
            
            return true;
            
        } catch(PDOException $e) {
            error_log("Registro error: " . $e->getMessage());
            return ["Error al registrar usuario: " . $e->getMessage()];
        }
    }
    
    public function actualizarAvatar($userId, $avatarFile) {
        try {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $ext = strtolower(pathinfo($avatarFile['name'], PATHINFO_EXTENSION));
            
            if (!in_array($ext, $allowed)) {
                return false;
            }
            
            if ($avatarFile['size'] > 5000000) {
                return false;
            }
            
            $newFileName = uniqid() . '_' . $userId . '.' . $ext;
            $uploadPath = UPLOAD_DIR . $newFileName;
            
            if (move_uploaded_file($avatarFile['tmp_name'], $uploadPath)) {
                $stmt = $this->db->prepare("UPDATE usuarios SET avatar = ? WHERE id = ?");
                $stmt->execute([$newFileName, $userId]);
                
                $_SESSION['user_avatar'] = $newFileName;
                
                return true;
            }
            return false;
        } catch(PDOException $e) {
            error_log("Avatar update error: " . $e->getMessage());
            return false;
        }
    }

    public function actualizarAvatarDefault($userId, $avatarFileName) {
        try {
            $stmt = $this->db->prepare("UPDATE usuarios SET avatar = ? WHERE id = ?");
            $stmt->execute([$avatarFileName, $userId]);
            
            // Actualizar la variable de sesión para mostrar el nuevo avatar inmediatamente
            $_SESSION['user_avatar'] = $avatarFileName;
            
            return true;
        } catch(PDOException $e) {
            error_log("Error al actualizar avatar predeterminado: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerPerfil($userId) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE id = ?");
            $stmt->execute([$userId]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            error_log("Obtener perfil error: " . $e->getMessage());
            return false;
        }
    }
    
    public function actualizarPuntos($userId, $puntos) {
        try {
            $stmt = $this->db->prepare("UPDATE usuarios SET puntos = puntos + ? WHERE id = ?");
            $stmt->execute([$puntos, $userId]);
            
            $_SESSION['user_puntos'] += $puntos;
            
            return true;
        } catch(PDOException $e) {
            error_log("Actualizar puntos error: " . $e->getMessage());
            return false;
        }
    }
    
    public function actualizarNivel($userId, $nivel) {
        try {
            $stmt = $this->db->prepare("UPDATE usuarios SET nivel_actual = ? WHERE id = ?");
            $stmt->execute([$nivel, $userId]);
            
            $_SESSION['user_nivel'] = $nivel;
            
            return true;
        } catch(PDOException $e) {
            error_log("Actualizar nivel error: " . $e->getMessage());
            return false;
        }
    }
    
    public function obtenerRanking() {
        try {
            $stmt = $this->db->prepare("
                SELECT id, nombre, apodo, puntos, avatar 
                FROM usuarios 
                WHERE activo = 1 
                ORDER BY puntos DESC 
                LIMIT 10
            ");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            error_log("Obtener ranking error: " . $e->getMessage());
            return [];
        }
    }
    
    public function buscarPorEmail($email) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            error_log("Buscar por email error: " . $e->getMessage());
            return false;
        }
    }
}
?>