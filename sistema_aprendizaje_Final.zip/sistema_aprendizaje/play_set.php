<?php
// play_set.php
require_once 'config.php';

$qrManager = new QRManager();
$usuario = new Usuario();

$codigo = isset($_GET['code']) ? $_GET['code'] : null;

if (!$codigo) {
    die("Código QR no válido");
}

$set = $qrManager->obtenerSetPorCodigo($codigo);

if (!$set) {
    die("Set de preguntas no encontrado");
}

// Procesar respuestas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respuestas'])) {
    $puntos_totales = 0;
    $respuestas_correctas = 0;
    
    $temaManager = new TemaManager();
    
    foreach ($_POST['respuestas'] as $pregunta_id => $respuesta) {
        $resultado = $temaManager->verificarRespuesta($pregunta_id, $respuesta);
        
        if ($resultado['correcta']) {
            $puntos_totales += $resultado['puntos'];
            $respuestas_correctas++;
        }
    }
    
    // Si el usuario está logueado, guardar sus puntos
    if (isset($_SESSION['user_id'])) {
        $usuario->actualizarPuntos($_SESSION['user_id'], $puntos_totales);
    }
    
    // Mostrar resultados
    echo "<script>
        alert('¡Juego terminado!\\nRespuestas correctas: $respuestas_correctas/" . count($set['preguntas']) . "\\nPuntos ganados: $puntos_totales');
        window.history.back();
    </script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jugar Set - Sistema de Aprendizaje</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="play-set-container">
        <header class="set-header">
            <h1><?php echo $set['nombre']; ?></h1>
            <p>Creado por: <?php echo $set['creador_nombre']; ?></p>
            <p>Tema: <?php echo $set['tema_nombre']; ?></p>
            <p>Nivel: <?php echo ucfirst($set['nivel']); ?></p>
        </header>
        
        <form method="POST" action="" class="quiz-form">
            <?php foreach ($set['preguntas'] as $index => $pregunta): ?>
            <div class="pregunta-card">
                <h3>Pregunta <?php echo $index + 1; ?></h3>
                <p class="pregunta-texto"><?php echo $pregunta['pregunta']; ?></p>
                <p class="puntos-info">Valor: <?php echo $pregunta['puntos']; ?> puntos</p>
                
                <?php if ($pregunta['tipo'] == 'multiple'): ?>
                    <div class="opciones">
                        <?php foreach ($pregunta['opciones'] as $key => $opcion): ?>
                        <div class="opcion">
                            <input type="radio" 
                                   id="p<?php echo $pregunta['id'] . '_' . $key; ?>" 
                                   name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                   value="<?php echo $key; ?>" 
                                   required>
                            <label for="p<?php echo $pregunta['id'] . '_' . $key; ?>">
                                <?php echo $opcion; ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php elseif ($pregunta['tipo'] == 'verdadero_falso'): ?>
                    <div class="opciones">
                        <div class="opcion">
                            <input type="radio" 
                                   id="p<?php echo $pregunta['id']; ?>_true" 
                                   name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                   value="true" 
                                   required>
                            <label for="p<?php echo $pregunta['id']; ?>_true">Verdadero</label>
                        </div>
                        <div class="opcion">
                            <input type="radio" 
                                   id="p<?php echo $pregunta['id']; ?>_false" 
                                   name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                   value="false" 
                                   required>
                            <label for="p<?php echo $pregunta['id']; ?>_false">Falso</label>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-large">Terminar Quiz</button>
            </div>
        </form>
        
        <footer class="set-footer">
            <p>Sistema de Aprendizaje - Set QR: <?php echo $codigo; ?></p>
        </footer>
    </div>
</body>
</html>