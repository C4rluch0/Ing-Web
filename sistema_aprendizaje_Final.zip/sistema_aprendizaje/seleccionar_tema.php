<?php
// seleccionar_tema.php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$temaManager = new TemaManager();
$qrManager = new QRManager(); 

$user_nivel = $_SESSION['user_nivel'];
$user_id = $_SESSION['user_id'];
$temas = $temaManager->obtenerTemas();

$mensaje = '';
$error = '';
$qr_display = null; // Para guardar la información del QR si se crea un set

// Definición de la jerarquía de niveles
$nivel_map = [
    'novato' => 1,
    'basico' => 2,
    'intermedio' => 3,
    'avanzado' => 4,
    'experto' => 5
];

$user_level_value = $nivel_map[$user_nivel] ?? 1;

// Agrupar temas por nivel para la visualización
$temas_agrupados = [];
foreach ($temas as $tema) {
    $temas_agrupados[$tema['nivel']][] = $tema;
}

// ==================== PROCESAR SOLICITUD DE JUEGO ====================
if (isset($_GET['tema']) && isset($_GET['mode'])) {
    $tema_id = intval($_GET['tema']);
    $mode = $_GET['mode'];
    
    $tema_seleccionado = $temaManager->obtenerTema($tema_id);
    
    if (!$tema_seleccionado) {
        $error = "❌ Tema no encontrado.";
    } else {
        $tema_level_value = $nivel_map[$tema_seleccionado['nivel']] ?? 1;
        
        // 1. RESTRICCIÓN DE NIVEL (Validación de seguridad en el backend)
        if ($user_level_value < $tema_level_value) {
            $error = "⚠️ Tu nivel (" . ucfirst($user_nivel) . ") es demasiado bajo para este tema (" . ucfirst($tema_seleccionado['nivel']) . "). ¡Sigue jugando para subir de nivel!";
        } else {
            // 2. MODOS DE JUEGO
            if ($mode === 'solo') {
                // Modo Solitario: Redirigir a jugar.php
                header("Location: jugar.php?tema=$tema_id");
                exit();
            } elseif ($mode === 'multi') {
                // Modo Multijugador: Crear Set y generar QR
                $nombre_set = "Multijugador - " . $tema_seleccionado['nombre'];
                $descripcion_set = "Set creado por " . $_SESSION['user_nombre'] . " para el tema " . $tema_seleccionado['nombre'];
                
                // Usar el nuevo método en QRManager
                $result = $qrManager->crearSetDesdeTema(
                    $user_id, 
                    $tema_id, 
                    $nombre_set, 
                    $descripcion_set
                );

                if (isset($result['codigo_qr'])) {
                    $mensaje = "✅ Set Multijugador creado. Comparte el código QR para que otros se unan.";
                    $qr_display = $result;
                } else {
                    $error = "❌ " . ($result['error'] ?? 'Error desconocido al crear el set multijugador.');
                }
            } else {
                $error = "Modo de juego no válido.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Tema para Jugar</title>
    <link rel="stylesheet" href="css/estilos.css">
    <style>
        .temas-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .nivel-seccion {
            background-color: #f4f4f4;
            padding: 15px;
            border-radius: 8px;
        }
        .nivel-seccion h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }
        .tema-card {
            background: white;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .tema-card.disabled {
            background-color: #ffeaea;
            border-left: 5px solid #ff4d4d;
            opacity: 0.6;
            pointer-events: none;
        }
        .tema-card.disabled .btn {
            background-color: #ccc;
            cursor: not-allowed;
        }
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            width: 90%;
            max-width: 400px;
        }
        .modal-content .btn {
            margin: 10px;
            padding: 10px 20px;
        }
        .qr-container {
            text-align: center;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>Nivel: <?php echo ucfirst($user_nivel); ?></p>
            </div>
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php">🎮 Jugar</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="mis_premios.php">🏆 Mis Premios</a>
                <a href="subir_avatar.php">👤 Avatar</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Seleccionar Tema</h1>
                <p>Tu nivel actual es: **<?php echo ucfirst($user_nivel); ?>**</p>
            </header>
            
            <?php if ($mensaje): ?>
                <div class="alert alert-success"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($qr_display): ?>
                <div class="qr-container">
                    <h3>¡Multijugador Listo!</h3>
                    <p>Comparte este código QR o la URL para que tus amigos se unan al set: <strong><?php echo htmlspecialchars($qr_display['codigo_qr']); ?></strong></p>
                    <img src="<?php echo htmlspecialchars($qr_display['qr_image']); ?>" alt="Código QR del Juego" style="max-width: 200px; margin: 15px 0;">
                    <p><a href="<?php echo htmlspecialchars($qr_display['url']); ?>" target="_blank" class="btn btn-secondary">Ir al Juego</a></p>
                    <button class="btn" onclick="window.location.href='seleccionar_tema.php'">Volver a Temas</button>
                </div>
            <?php else: ?>
                <div class="temas-container">
                    <?php 
                    // Nivel de dificultad en orden
                    $niveles_ordenados = ['basico', 'intermedio', 'avanzado', 'experto'];
                    $niveles_ordenados_display = [
                        'basico' => 'Básico 🟢', 
                        'intermedio' => 'Intermedio 🟡', 
                        'avanzado' => 'Avanzado 🟠', 
                        'experto' => 'Experto 🔴'
                    ];

                    foreach ($niveles_ordenados as $nivel_tema): 
                        if (isset($temas_agrupados[$nivel_tema])): 
                            $tema_level_value = $nivel_map[$nivel_tema];
                            $is_locked = $user_level_value < $tema_level_value;
                    ?>
                        <div class="nivel-seccion">
                            <h2><?php echo $niveles_ordenados_display[$nivel_tema] ?? ucfirst($nivel_tema); ?></h2>
                            <?php if ($is_locked): ?>
                                <p style="color: #ff4d4d; font-weight: bold;">🔒 Nivel Bloqueado. Necesitas ser **<?php echo ucfirst($nivel_tema); ?>** para jugar estos temas.</p>
                            <?php endif; ?>
                            
                            <?php foreach ($temas_agrupados[$nivel_tema] as $tema): 
                                $disabled_class = $is_locked ? 'disabled' : '';
                            ?>
                                <div class="tema-card <?php echo $disabled_class; ?>">
                                    <div>
                                        <strong><?php echo htmlspecialchars($tema['nombre']); ?></strong>
                                        <p style="font-size: 0.9em; color: #666;"><?php echo htmlspecialchars($tema['descripcion']); ?></p>
                                    </div>
                                    <div>
                                        <?php if ($is_locked): ?>
                                            <button class="btn" disabled>Bloqueado</button>
                                        <?php else: ?>
                                            <button class="btn btn-primary" onclick="abrirModal(<?php echo $tema['id']; ?>)">
                                                Jugar 🎮
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php 
                        endif; 
                    endforeach; 
                    ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div id="modalModo" class="modal-overlay">
        <div class="modal-content">
            <h2>Seleccionar Modo de Juego</h2>
            <p>¿Cómo deseas jugar **<span id="temaNombreModal"></span>**?</p>
            <a href="#" id="linkSolo" class="btn btn-success">Solitario 👤</a>
            <a href="#" id="linkMulti" class="btn btn-info">Multijugador 👥</a>
            <button class="btn btn-secondary" onclick="cerrarModal()">Cancelar</button>
        </div>
    </div>

    <script>
    var temas = <?php echo json_encode($temas); ?>;
    var modal = document.getElementById('modalModo');
    var temaNombreModal = document.getElementById('temaNombreModal');
    var linkSolo = document.getElementById('linkSolo');
    var linkMulti = document.getElementById('linkMulti');
    
    function abrirModal(temaId) {
        // Encontrar el nombre del tema
        var tema = temas.find(t => t.id == temaId);
        
        if (tema) {
            temaNombreModal.textContent = tema.nombre;
            linkSolo.href = 'seleccionar_tema.php?tema=' + temaId + '&mode=solo';
            linkMulti.href = 'seleccionar_tema.php?tema=' + temaId + '&mode=multi';
            modal.style.display = 'flex';
        }
    }
    
    function cerrarModal() {
        modal.style.display = 'none';
    }
    </script>
</body>
</html>