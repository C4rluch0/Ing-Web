<?php
// jugar.php
require_once 'config.php';

// ==========================================================
// 1. Inicialización y Obtención del Tema (CORRECCIÓN CLAVE)
// ==========================================================
$temaManager = new TemaManager();
$usuario = new Usuario();

$tema_id = isset($_GET['tema']) ? intval($_GET['tema']) : null;

// REDIRECCIÓN: Si no hay tema ID, redirigir a la página de selección
if (!$tema_id) {
    header('Location: seleccionar_tema.php');
    exit();
}

// Obtener la información del tema (NECESARIO para título y verificación)
$tema = $temaManager->obtenerTema($tema_id);
if (!$tema) {
    // Si el tema no existe o no está activo
    header('Location: seleccionar_tema.php');
    exit();
}

// ==========================================================
// 2. Obtener Preguntas y Preparar Vista
// ==========================================================
// Obtener preguntas para el tema seleccionado.
$preguntas = $temaManager->obtenerPreguntas($tema_id);

// Limitar a 10 preguntas (o el número de preguntas disponibles)
$preguntas = array_slice($preguntas, 0, 10);

$nombre_tema = $tema['nombre'];
$mensaje = '';

if (empty($preguntas)) {
    // Si no hay preguntas, se establece un mensaje de error que se muestra en la vista
    $mensaje = "No hay preguntas disponibles para el tema: " . htmlspecialchars($nombre_tema);
}


// ==========================================================
// 3. Procesar Respuestas (Mismo código que tenías)
// ==========================================================
// Procesar respuestas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respuestas'])) {
    $puntos_totales = 0;
    $respuestas_correctas = 0;
    
    foreach ($_POST['respuestas'] as $pregunta_id => $respuesta) {
        $resultado = $temaManager->verificarRespuesta($pregunta_id, $respuesta);
        
        if ($resultado['correcta']) {
            $puntos_totales += $resultado['puntos'];
            $respuestas_correctas++;
        }
    }
    
    // 1. ACTUALIZAR PUNTOS EN LA BASE DE DATOS
    // --- Lógica Corregida de Subida de Nivel ---
    
    // Asumimos que la sesión fue actualizada por actualizarPuntos
    $total_puntos_actualizado = $_SESSION['user_puntos'] ?? 0;
    $nivel_actual = $_SESSION['user_nivel'];
    
    $usuario->actualizarPuntos($_SESSION['user_id'], $puntos_totales);
    $puntos_acumulados = $_SESSION['user_puntos'];
    // Los umbrales se comprueban con el TOTAL acumulado, no solo los puntos del juego ($puntos_totales)
    
    if ($puntos_acumulados >= 100 && $_SESSION['user_nivel'] == 'novato') {
        $usuario->actualizarNivel($_SESSION['user_id'], 'basico');
    } elseif ($puntos_acumulados >= 300 && $_SESSION['user_nivel'] == 'basico') {
        $usuario->actualizarNivel($_SESSION['user_id'], 'intermedio');
    } elseif ($puntos_acumulados >= 500 && $_SESSION['user_nivel'] == 'intermedio') {
        $usuario->actualizarNivel($_SESSION['user_id'], 'avanzado');
    } elseif ($puntos_acumulados >= 1000 && $_SESSION['user_nivel'] == 'avanzado') {
        $usuario->actualizarNivel($_SESSION['user_id'], 'experto');
    }
    
    // --- Fin Lógica Corregida ---
    
    // Mostrar resultados
    echo "<script>
        alert('¡Juego terminado!\\nRespuestas correctas: $respuestas_correctas/" . count($_POST['respuestas']) . "\\nPuntos ganados: $puntos_totales\\nNuevo Nivel: " . ucfirst($_SESSION['user_nivel']) . "');
        window.location.href = 'dashboard.php';
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jugar - <?php echo htmlspecialchars($nombre_tema ?? 'Trivia'); ?></title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>@<?php echo $_SESSION['user_apodo']; ?></p>
                <div class="puntos">
                    <span class="puntos-numero"><?php echo $_SESSION['user_puntos']; ?></span> puntos
                </div>
                <p>Nivel: <?php echo ucfirst($_SESSION['user_nivel']); ?></p>
            </div>
            
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php" class="active">🎮 Jugar</a>
                <a href="crear_set.php">📚 Crear Sets</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Quiz: <?php echo htmlspecialchars($nombre_tema ?? 'Cargando...'); ?> (<?php echo ucfirst($tema['nivel'] ?? ''); ?>)</h1>
            </header>
            
            <?php if (!empty($mensaje)): ?>
                <div class="alert alert-warning"><?php echo $mensaje; ?></div>
                <div class="form-actions">
                    <a href="seleccionar_tema.php" class="btn btn-primary">← Seleccionar otro tema</a>
                </div>
            <?php else: ?>
                <form method="POST" action="jugar.php?tema=<?php echo $tema_id; ?>" class="quiz-form">
                    <?php foreach ($preguntas as $index => $pregunta): ?>
                    <div class="pregunta-card">
                        <h3>Pregunta <?php echo $index + 1; ?></h3>
                        <p class="pregunta-texto"><?php echo $pregunta['pregunta']; ?></p>
                        <p class="puntos-info">Valor: <?php echo $pregunta['puntos']; ?> puntos</p>
                        
                        <?php if ($pregunta['tipo'] == 'multiple'): ?>
                            <div class="opciones">
                                <?php foreach ($pregunta['opciones'] as $key => $opcion): ?>
                                <div class="opcion">
                                    <input type="radio" 
                                           id="p<?php echo $pregunta['id'] . '_' . $key; ?>" 
                                           name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                           value="<?php echo $key; ?>" 
                                           required>
                                    <label for="p<?php echo $pregunta['id'] . '_' . $key; ?>">
                                        <?php echo $opcion; ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($pregunta['tipo'] == 'verdadero_falso'): ?>
                            <div class="opciones">
                                <div class="opcion">
                                    <input type="radio" 
                                           id="p<?php echo $pregunta['id']; ?>_true" 
                                           name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                           value="true" 
                                           required>
                                    <label for="p<?php echo $pregunta['id']; ?>_true">Verdadero</label>
                                </div>
                                <div class="opcion">
                                    <input type="radio" 
                                           id="p<?php echo $pregunta['id']; ?>_false" 
                                           name="respuestas[<?php echo $pregunta['id']; ?>]" 
                                           value="false" 
                                           required>
                                    <label for="p<?php echo $pregunta['id']; ?>_false">Falso</label>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-large">Terminar Quiz</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>