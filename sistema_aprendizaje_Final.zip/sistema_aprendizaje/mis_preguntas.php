<?php
// mis_preguntas.php - VERSIÓN SIMPLIFICADA
require_once 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$temaManager = new TemaManager();
$temas = $temaManager->obtenerTemas();

$mensaje = '';
$error = '';

// ==================== PROCESAR CREACIÓN DE TEMA ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_tema'])) {
    $data = [
        'nombre' => $_POST['nombre_tema'],
        'descripcion' => $_POST['descripcion_tema'],
        'nivel' => $_POST['nivel_tema']
    ];
    
    $result = $temaManager->crearTema($data);
    
    if ($result) {
        $mensaje = "✅ Tema creado exitosamente";
        $temas = $temaManager->obtenerTemas(); // Actualizar lista
    } else {
        $error = "❌ Error al crear el tema";
    }
}

// ==================== PROCESAR CREACIÓN DE PREGUNTA ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_pregunta'])) {
    $data = [
        'tema_id' => $_POST['tema_id'],
        'pregunta' => $_POST['pregunta'],
        'tipo' => $_POST['tipo'],
        'puntos' => $_POST['puntos']
    ];
    
    // Preparar opciones según el tipo
    if ($_POST['tipo'] == 'multiple') {
        $opciones = [
            'a' => $_POST['opcion_a'],
            'b' => $_POST['opcion_b']
        ];
        // Agregar opciones C y D si no están vacías
        if (!empty($_POST['opcion_c'])) $opciones['c'] = $_POST['opcion_c'];
        if (!empty($_POST['opcion_d'])) $opciones['d'] = $_POST['opcion_d'];
        
        $data['opciones'] = $opciones;
        $data['respuesta_correcta'] = $_POST['respuesta_correcta'];
    } else { // verdadero_falso
        $data['opciones'] = ['true' => 'Verdadero', 'false' => 'Falso'];
        $data['respuesta_correcta'] = $_POST['respuesta_vf'];
    }
    
    $result = $temaManager->crearPregunta($data);
    
    if ($result) {
        $mensaje = "✅ Pregunta creada exitosamente";
    } else {
        $error = "❌ Error al crear la pregunta";
    }
}

// Obtener preguntas del usuario actual
$preguntas_usuario = $temaManager->obtenerPreguntasUsuario($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Preguntas y Temas</title>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/mis_preguntas.css">
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>@<?php echo $_SESSION['user_apodo']; ?></p>
                <p>Nivel: <?php echo ucfirst($_SESSION['user_nivel']); ?></p>
            </div>
            
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php">🎮 Jugar</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="mis_premios.php">🏆 Mis Premios</a>
                <a href="subir_avatar.php">👤 Avatar</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Mis Preguntas y Temas</h1>
                <p>Crea y gestiona tus temas y preguntas</p>
            </header>
            
            <?php if ($mensaje): ?>
                <div class="alert alert-success"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- ==================== SECCIÓN 1: CREAR NUEVO TEMA ==================== -->
            <div class="seccion-crear">
                <h2><span class="icono">📖</span> Crear Nuevo Tema</h2>
                <form method="POST" action="" class="form-tema">
                    <div class="form-group">
                        <label for="nombre_tema">Nombre del tema:</label>
                        <input type="text" id="nombre_tema" name="nombre_tema" required 
                               placeholder="Ej: Matemáticas Básicas, Historia del Arte">
                    </div>
                    
                    <div class="form-group">
                        <label for="descripcion_tema">Descripción:</label>
                        <textarea id="descripcion_tema" name="descripcion_tema" rows="3" 
                                  placeholder="Describe brevemente el tema..."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="nivel_tema">Nivel de dificultad:</label>
                        <select id="nivel_tema" name="nivel_tema" required>
                            <option value="basico">Básico</option>
                            <option value="intermedio">Intermedio</option>
                            <option value="avanzado">Avanzado</option>
                            <option value="experto">Experto</option>
                        </select>
                    </div>
                    
                    <button type="submit" name="crear_tema" class="btn btn-success">
                        <span class="btn-icon">✅</span> Crear Nuevo Tema
                    </button>
                </form>
            </div>
            
            <!-- ==================== SECCIÓN 2: CREAR PREGUNTA (VERSIÓN SIMPLIFICADA) ==================== -->
            <div class="seccion-crear">
                <h2><span class="icono">❓</span> Crear Nueva Pregunta</h2>
                
                <form method="POST" action="" id="formPregunta" class="form-pregunta">
                    <!-- Campo 1: Tema -->
                    <div class="form-group">
                        <label for="tema_id">Seleccionar tema: *</label>
                        <select id="tema_id" name="tema_id">
                            <option value="">-- Selecciona un tema --</option>
                            <?php foreach ($temas as $tema): ?>
                                <option value="<?php echo $tema['id']; ?>">
                                    <?php echo htmlspecialchars($tema['nombre']); ?> 
                                    (<?php echo ucfirst($tema['nivel']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Campo 2: Pregunta -->
                    <div class="form-group">
                        <label for="pregunta">Pregunta: *</label>
                        <textarea id="pregunta" name="pregunta" rows="3" 
                                placeholder="Escribe la pregunta aquí..."></textarea>
                    </div>
                    
                    <!-- Campo 3: Tipo -->
                    <div class="form-group">
                        <label for="tipo">Tipo de pregunta: *</label>
                        <select id="tipo" name="tipo" onchange="mostrarOpciones()">
                            <option value="multiple">Opción múltiple</option>
                            <option value="verdadero_falso">Verdadero/Falso</option>
                        </select>
                    </div>
                    
                    <!-- Opciones múltiple (SIMPLIFICADO) -->
                    <div id="opciones_multiple" class="opciones-container">
                        <p><strong>Opciones de respuesta:</strong> (llena al menos A y B)</p>
                        
                        <div class="form-group">
                            <label>A:</label>
                            <input type="text" name="opcion_a" class="opcion-input" placeholder="Texto para opción A">
                        </div>
                        
                        <div class="form-group">
                            <label>B:</label>
                            <input type="text" name="opcion_b" class="opcion-input" placeholder="Texto para opción B">
                        </div>
                        
                        <div class="form-group">
                            <label>C (opcional):</label>
                            <input type="text" name="opcion_c" class="opcion-input" placeholder="Texto para opción C">
                        </div>
                        
                        <div class="form-group">
                            <label>D (opcional):</label>
                            <input type="text" name="opcion_d" class="opcion-input" placeholder="Texto para opción D">
                        </div>
                        
                        <div class="form-group">
                            <label><strong>¿Cuál es la respuesta correcta?</strong></label>
                            <div style="margin-top: 10px;">
                                <label style="display: block; margin: 5px 0;">
                                    <input type="radio" name="respuesta_correcta" value="a"> Opción A
                                </label>
                                <label style="display: block; margin: 5px 0;">
                                    <input type="radio" name="respuesta_correcta" value="b"> Opción B
                                </label>
                                <label style="display: block; margin: 5px 0;">
                                    <input type="radio" name="respuesta_correcta" value="c"> Opción C
                                </label>
                                <label style="display: block; margin: 5px 0;">
                                    <input type="radio" name="respuesta_correcta" value="d"> Opción D
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Opciones verdadero/falso -->
                    <div id="opciones_vf" class="opciones-container" style="display: none;">
                        <div class="form-group">
                            <label><strong>Selecciona la respuesta correcta:</strong></label>
                            <div style="margin-top: 10px;">
                                <label style="display: block; margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 5px;">
                                    <input type="radio" name="respuesta_vf" value="true"> ✅ Verdadero
                                </label>
                                <label style="display: block; margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 5px;">
                                    <input type="radio" name="respuesta_vf" value="false"> ❌ Falso
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Campo 5: Puntos -->
                    <div class="form-group">
                        <label for="puntos">Puntos por respuesta correcta:</label>
                        <input type="number" id="puntos" name="puntos" value="10" min="1" max="100">
                        <small style="color: #666; display: block; margin-top: 5px;">(1-100 puntos)</small>
                    </div>
                    
                    <!-- Botón -->
                    <button type="submit" name="crear_pregunta" class="btn btn-primary" 
                            onclick="return confirm('¿Crear esta pregunta?')">
                        <span class="btn-icon">✅</span> Crear Pregunta
                    </button>
                    
                    <small style="color: #666; display: block; margin-top: 15px;">
                        * Campos obligatorios
                    </small>
                </form>
            </div>
            
            <!-- ==================== SECCIÓN 3: MIS PREGUNTAS ==================== -->
            <div class="seccion-preguntas">
                <h2><span class="icono">📋</span> Mis Preguntas Creadas (<?php echo count($preguntas_usuario); ?>)</h2>
                
                <?php if (empty($preguntas_usuario)): ?>
                    <div class="estado-vacio">
                        <h3>📭 Aún no has creado preguntas</h3>
                        <p>¡Usa el formulario arriba para crear tu primera pregunta!</p>
                    </div>
                <?php else: ?>
                    <div class="lista-preguntas">
                        <?php foreach ($preguntas_usuario as $pregunta): ?>
                        <div class="pregunta-card">
                            <h4 class="pregunta-titulo"><?php echo htmlspecialchars($pregunta['pregunta']); ?></h4>
                            <div class="pregunta-meta">
                                <span class="badge badge-tipo">Tipo: <?php echo $pregunta['tipo']; ?></span>
                                <span class="puntos-badge">Puntos: <?php echo $pregunta['puntos']; ?></span>
                            </div>
                            <p class="pregunta-tema"><strong>Tema:</strong> <?php echo $pregunta['tema_nombre']; ?></p>
                            
                            <?php if ($pregunta['tipo'] == 'multiple' && !empty($pregunta['opciones'])): ?>
                                <div class="pregunta-opciones">
                                    <p><strong>Opciones:</strong></p>
                                    <ul class="lista-opciones">
                                        <?php foreach ($pregunta['opciones'] as $key => $valor): ?>
                                            <li class="opcion-item <?php echo ($key == $pregunta['respuesta_correcta']) ? 'opcion-correcta' : ''; ?>">
                                                <?php echo $key; ?>. <?php echo htmlspecialchars($valor); ?>
                                                <?php if ($key == $pregunta['respuesta_correcta']): ?>
                                                    <span class="indicador-correcto">✓ Correcta</span>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php else: ?>
                                <p class="pregunta-respuesta">
                                    <strong>Respuesta correcta:</strong> 
                                    <span class="respuesta-vf <?php echo ($pregunta['respuesta_correcta'] == 'true') ? 'verdadero' : 'falso'; ?>">
                                        <?php echo ($pregunta['respuesta_correcta'] == 'true') ? '✅ Verdadero' : '❌ Falso'; ?>
                                    </span>
                                </p>
                            <?php endif; ?>
                            
                            <div class="pregunta-acciones">
                                <button class="btn btn-editar" onclick="editarPregunta(<?php echo $pregunta['id']; ?>)">
                                    ✏️ Editar
                                </button>
                                <button class="btn btn-eliminar" onclick="eliminarPregunta(<?php echo $pregunta['id']; ?>)">
                                    🗑️ Eliminar
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
    // Mostrar/ocultar opciones según tipo de pregunta
    function mostrarOpciones() {
        var tipo = document.getElementById('tipo').value;
        var opcionesMultiple = document.getElementById('opciones_multiple');
        var opcionesVF = document.getElementById('opciones_vf');
        
        if (tipo == 'multiple') {
            opcionesMultiple.style.display = 'block';
            opcionesVF.style.display = 'none';
        } else {
            opcionesMultiple.style.display = 'none';
            opcionesVF.style.display = 'block';
        }
    }
    
    function editarPregunta(id) {
        if (confirm('¿Editar esta pregunta?')) {
            window.location.href = 'editar_pregunta.php?id=' + id;
        }
    }
    
    function eliminarPregunta(id) {
        if (confirm('¿Eliminar esta pregunta? Esta acción no se puede deshacer.')) {
            window.location.href = 'eliminar_pregunta.php?id=' + id;
        }
    }
    
    // Validación simple del formulario
    document.getElementById('formPregunta').addEventListener('submit', function(e) {
        var temaId = document.getElementById('tema_id').value;
        if (!temaId) {
            e.preventDefault();
            alert('⚠️ Por favor, selecciona un tema para la pregunta');
            document.getElementById('tema_id').focus();
            return false;
        }
        
        var pregunta = document.getElementById('pregunta').value.trim();
        if (!pregunta) {
            e.preventDefault();
            alert('⚠️ Por favor, escribe la pregunta');
            document.getElementById('pregunta').focus();
            return false;
        }
        
        return true;
    });
    
    // Inicializar
    mostrarOpciones();
    </script>
</body>
</html>