<?php
// reclamar_premio.php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 1. Verificar que la solicitud es POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "❌ Solicitud no válida. Por favor, reclama el premio desde la página 'Mis Premios'.";
    header('Location: mis_premios.php');
    exit();
}

// 2. Obtener el ID del premio desde el POST
$premio_id = isset($_POST['premio_id']) ? intval($_POST['premio_id']) : 0;

if (!$premio_id) {
    $_SESSION['error'] = "❌ ID de premio no especificado.";
    header('Location: mis_premios.php');
    exit();
}

$premioManager = new PremioManager();

// 3. Verificar si el premio es reclamable
// La función verificarPremioUsuario devuelve solo los premios que CUMPLEN
// los requisitos (puntos, nivel) y que NO HAN SIDO RECLAMADOS.
$premios_disponibles_a_reclamar = $premioManager->verificarPremioUsuario($_SESSION['user_id']);

$premio_info = null; // Para guardar la información del premio si se encuentra
$premio_valido_para_reclamar = false;

foreach ($premios_disponibles_a_reclamar as $premio) {
    if ($premio['id'] == $premio_id) {
        $premio_info = $premio; // Obtener detalles del premio
        $premio_valido_para_reclamar = true;
        break;
    }
}

// 4. Si no es válido para reclamar, dar feedback específico
if (!$premio_valido_para_reclamar) {
    // Si no está en la lista de reclamables, buscar el premio para un mensaje de error más específico
    $premio_detalles = $premioManager->obtenerPremioPorId($premio_id);
    
    // Si el premio no existe o está inactivo
    if (!$premio_detalles) {
        $_SESSION['error'] = "❌ El premio solicitado no existe o no está activo.";
        header('Location: mis_premios.php?tab=3'); // Redirigir al catálogo
        exit();
    }

    // Obtener datos del usuario para chequear por qué no es reclamable
    $usuario = new Usuario();
    $perfil = $usuario->obtenerPerfil($_SESSION['user_id']); 
    $puntos_usuario = $perfil['puntos'] ?? 0;
    $nivel_usuario = $perfil['nivel_actual'] ?? 'novato';

    // Se repite la lógica de nivel para el mensaje de error (podría ser un método de la clase Usuario)
    $orden_niveles = ['novato' => 0, 'basico' => 1, 'intermedio' => 2, 'avanzado' => 3, 'experto' => 4];
    $nivel_ok = ($orden_niveles[$nivel_usuario] ?? 0) >= ($orden_niveles[$premio_detalles['nivel_requerido']] ?? 0);
    $puntos_ok = $puntos_usuario >= $premio_detalles['puntos_requeridos'];
    
    // Asumiendo que PremioManager::obtenerPremiosUsuario existe
    $premios_obtenidos = $premioManager->obtenerPremiosUsuario($_SESSION['user_id']);
    $ya_obtenido = in_array($premio_id, array_column($premios_obtenidos, 'id'));
    
    $error_msg = "❌ No puedes reclamar este premio: ";

    if ($ya_obtenido) {
        $error_msg = "❌ Ya has reclamado este premio anteriormente.";
    } elseif (!$nivel_ok && !$puntos_ok) {
        $error_msg .= "Requiere nivel " . ucfirst($premio_detalles['nivel_requerido']) . " y te faltan " . ($premio_detalles['puntos_requeridos'] - $puntos_usuario) . " puntos.";
    } elseif (!$nivel_ok) {
        $error_msg .= "Requiere nivel " . ucfirst($premio_detalles['nivel_requerido']) . ".";
    } elseif (!$puntos_ok) {
        $error_msg .= "Te faltan " . ($premio_detalles['puntos_requeridos'] - $puntos_usuario) . " puntos.";
    }

    $_SESSION['error'] = $error_msg;
    header('Location: mis_premios.php?tab=3'); // Redirigir al catálogo con el error
    exit();
}

// 5. Asignar el premio (solo si es un logro y no cuesta puntos)
// Si el premio fuera a costar puntos, aquí se llamaría a un método de Usuario
// para descontar los puntos y luego asignar el premio.
if ($premioManager->asignarPremio($_SESSION['user_id'], $premio_id)) {
    // Éxito
    $_SESSION['mensaje_exito'] = "🎉 ¡Premio **" . htmlspecialchars($premio_info['nombre']) . "** reclamado exitosamente!";
    header('Location: mis_premios.php?tab=1'); // Mostrar pestaña de Obtenidos
    exit();
} else {
    // Error al insertar en la base de datos
    $_SESSION['error'] = "❌ Error interno al asignar el premio. Inténtalo de nuevo.";
    header('Location: mis_premios.php?tab=2'); // Mostrar pestaña de Reclamables
    exit();
}
?>