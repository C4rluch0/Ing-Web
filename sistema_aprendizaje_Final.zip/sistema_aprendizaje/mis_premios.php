<?php
// mis_premios.php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$premioManager = new PremioManager();
$usuario = new Usuario();

// Manejar mensajes de sesión (si vienen de reclamar_premio.php)
$mensaje = $_SESSION['mensaje_exito'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje_exito'], $_SESSION['error']);


// Obtener premios del usuario
$premios_obtenidos = $premioManager->obtenerPremiosUsuario($_SESSION['user_id']);
// Obtener premios disponibles para reclamar (Cumple requisitos y no reclamado)
$premios_disponibles_a_reclamar = $premioManager->verificarPremioUsuario($_SESSION['user_id']);
// NUEVO: Obtener todos los premios disponibles en el sistema
$todos_los_premios = $premioManager->obtenerTodosLosPremios(); 

// Crear un array de IDs de premios obtenidos para una búsqueda rápida
$premios_obtenidos_ids = array_column($premios_obtenidos, 'id');

// Crear un array de IDs de premios disponibles para reclamar
$premios_disponibles_ids = array_column($premios_disponibles_a_reclamar, 'id');

// Obtener datos del usuario para verificar el estado de los premios en el Catálogo
$perfil = $usuario->obtenerPerfil($_SESSION['user_id']); // Asumiendo que obtenerPerfil devuelve puntos y nivel
$puntos_usuario = $perfil['puntos'] ?? 0;
$nivel_usuario = $perfil['nivel_actual'] ?? 'novato';


// Función de ayuda para determinar si el nivel requerido está disponible
// (Esta lógica debería estar en Usuario.php o PremioManager.php, pero se incluye aquí para la vista)
function esNivelRequerido($premio_nivel, $user_nivel) {
    // Definir el orden de los niveles (de menor a mayor)
    $orden_niveles = ['novato' => 0, 'basico' => 1, 'intermedio' => 2, 'avanzado' => 3, 'experto' => 4];
    
    return ($orden_niveles[$user_nivel] ?? 0) >= ($orden_niveles[$premio_nivel] ?? 0);
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Premios</title>
    <link rel="stylesheet" href="css/estilos.css">
    </head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="user-info">
                <img src="avatars/<?php echo $_SESSION['user_avatar']; ?>" alt="Avatar" class="avatar">
                <h3><?php echo $_SESSION['user_nombre']; ?></h3>
                <p>@<?php echo $_SESSION['user_apodo']; ?></p>
                <div class="puntos">
                    <span class="puntos-numero"><?php echo $puntos_usuario; ?></span> puntos
                </div>
                <p>Nivel: <?php echo ucfirst($nivel_usuario); ?></p>
            </div>
            
            <nav class="menu">
                <a href="dashboard.php">🏠 Inicio</a>
                <a href="seleccionar_tema.php">🎮 Jugar</a>
                <a href="mis_preguntas.php">❓ Mis Preguntas</a>
                <a href="mis_premios.php">🏆 Mis Premios</a>
                <a href="subir_avatar.php">👤 Avatar</a>
                <a href="logout.php">🚪 Salir</a>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Mis Recompensas</h1>
            </header>
            
            <?php if ($mensaje): ?>
                <div class="alert alert-success"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="tabs-premios">
                <button class="tab-premio active" onclick="cambiarTabPremio(1)">Obtenidos (<?php echo count($premios_obtenidos); ?>)</button>
                <button class="tab-premio" onclick="cambiarTabPremio(2)">Reclamables (<?php echo count($premios_disponibles_a_reclamar); ?>)</button>
                <button class="tab-premio" onclick="cambiarTabPremio(3)">Catálogo Total (<?php echo count($todos_los_premios); ?>)</button> </div>
            
            <div id="tab1-content" class="tab-content-premio active">
                <h2>Premios que ya tienes</h2>
                <?php if (empty($premios_obtenidos)): ?>
                    <p class="empty-state">Aún no has reclamado ningún premio.</p>
                <?php else: ?>
                    <div class="premios-grid">
                        <?php foreach ($premios_obtenidos as $premio): ?>
                        <div class="premio-card obtained">
                            <img src="uploads/premios/<?php echo $premio['imagen']; ?>" alt="<?php echo $premio['nombre']; ?>">
                            <h3><?php echo htmlspecialchars($premio['nombre']); ?></h3>
                            <p><?php echo htmlspecialchars($premio['descripcion']); ?></p>
                            <div class="premio-footer">
                                <span class="badge">Obtenido el: <?php echo date('d/m/Y', strtotime($premio['fecha_obtencion'])); ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="tab2-content" class="tab-content-premio">
                <h2>Premios listos para reclamar</h2>
                <?php if (empty($premios_disponibles_a_reclamar)): ?>
                    <p class="empty-state">No tienes premios listos para reclamar en este momento. ¡Sigue jugando!</p>
                <?php else: ?>
                    <div class="premios-grid">
                        <?php foreach ($premios_disponibles_a_reclamar as $premio): ?>
                        <div class="premio-card claimable">
                            <img src="uploads/premios/<?php echo $premio['imagen']; ?>" alt="<?php echo $premio['nombre']; ?>">
                            <h3><?php echo htmlspecialchars($premio['nombre']); ?></h3>
                            <p><?php echo htmlspecialchars($premio['descripcion']); ?></p>
                            <div class="premio-footer">
                                <p class="cost">Costo: <?php echo $premio['puntos_requeridos']; ?> Puntos</p>
                                <form action="reclamar_premio.php" method="POST">
                                    <input type="hidden" name="premio_id" value="<?php echo $premio['id']; ?>">
                                    <button type="submit" class="btn btn-primary" onclick="return confirm('¿Reclamar el premio: <?php echo addslashes($premio['nombre']); ?>?')">
                                        🎁 Reclamar Premio
                                    </button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="tab3-content" class="tab-content-premio">
                <h2>Catálogo completo de premios</h2>
                <?php if (empty($todos_los_premios)): ?>
                    <p class="empty-state">No hay premios definidos en el sistema aún.</p>
                <?php else: ?>
                    <div class="premios-grid">
                        <?php foreach ($todos_los_premios as $premio): 
                            $es_obtenido = in_array($premio['id'], $premios_obtenidos_ids);
                            $es_reclamable = in_array($premio['id'], $premios_disponibles_ids);
                            $clase_estado = $es_obtenido ? 'obtained' : ($es_reclamable ? 'claimable' : 'locked');
                        ?>
                        <div class="premio-card <?php echo $clase_estado; ?>">
                            <img src="uploads/premios/<?php echo $premio['imagen']; ?>" alt="<?php echo $premio['nombre']; ?>">
                            <h3><?php echo htmlspecialchars($premio['nombre']); ?></h3>
                            <p><?php echo htmlspecialchars($premio['descripcion']); ?></p>
                            <div class="premio-requirements">
                                <p>Nivel requerido: <strong><?php echo ucfirst($premio['nivel_requerido']); ?></strong></p>
                                <p>Puntos: <strong><?php echo $premio['puntos_requeridos']; ?></strong></p>
                            </div>
                            <div class="premio-footer">
                                <?php if ($es_obtenido): ?>
                                    <span class="status-badge obtained-status">✅ ¡Obtenido!</span>
                                <?php elseif ($es_reclamable): ?>
                                    <form action="reclamar_premio.php" method="POST">
                                        <input type="hidden" name="premio_id" value="<?php echo $premio['id']; ?>">
                                        <button type="submit" class="btn btn-primary btn-small">
                                            🎁 Reclamar
                                        </button>
                                    </form>
                                <?php else: 
                                    $puntos_ok = $puntos_usuario >= $premio['puntos_requeridos'];
                                    $nivel_ok = esNivelRequerido($premio['nivel_requerido'], $nivel_usuario);
                                ?>
                                    <span class="status-badge locked-status">
                                        ❌ Bloqueado: 
                                        <?php if (!$nivel_ok) echo 'Nivel ' . ucfirst($premio['nivel_requerido']) . ' requerido.'; ?>
                                        <?php if (!$puntos_ok) echo ' Faltan puntos.'; ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <script>
                function cambiarTabPremio(tabNum) {
                    // Ocultar todas las pestañas y desactivar botones
                    document.querySelectorAll('.tab-content-premio').forEach(tab => {
                        tab.classList.remove('active');
                    });
                    document.querySelectorAll('.tab-premio').forEach(tab => {
                        tab.classList.remove('active');
                    });
                    
                    // Mostrar la pestaña seleccionada y activar botón
                    document.getElementById('tab' + tabNum + '-content').classList.add('active');
                    document.querySelectorAll('.tab-premio')[tabNum - 1].classList.add('active');
                }
                
                // Activar pestaña al cargar
                window.onload = function() {
                    const urlParams = new URLSearchParams(window.location.search);
                    // Si no hay tab en la URL, se activa la primera pestaña por defecto (Obtenidos)
                    const tabToActivate = urlParams.has('tab') ? parseInt(urlParams.get('tab')) : 1;
                    cambiarTabPremio(tabToActivate);
                }
            </script>
        </div>
    </div>
</body>
</html>