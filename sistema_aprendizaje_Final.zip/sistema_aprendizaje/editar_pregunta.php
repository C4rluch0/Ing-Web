<?php
// editar_pregunta.php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$temaManager = new TemaManager();
$pregunta_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$pregunta_id) {
    header('Location: mis_preguntas.php');
    exit();
}

// Obtener la pregunta
$pregunta = $temaManager->obtenerPregunta($pregunta_id);

if (!$pregunta) {
    die("Pregunta no encontrada");
}

// Verificar permisos (por ahora todos pueden editar)
// if (!$temaManager->puedeEditarPregunta($pregunta_id, $_SESSION['user_id'])) {
//     die("No tienes permiso para editar esta pregunta");
// }

$temas = $temaManager->obtenerTemas();
$mensaje = '';
$error = '';

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'tema_id' => $_POST['tema_id'], // Se añade tema_id
        'pregunta' => $_POST['pregunta'],
        'tipo' => $_POST['tipo'],
        // 'nivel' => $_POST['nivel'], // MODIFICADO: Eliminado
        'puntos' => $_POST['puntos']
    ];
    
    // Preparar opciones según el tipo
    if ($_POST['tipo'] == 'multiple') {
        $opciones = [
            'a' => $_POST['opcion_a'],
            'b' => $_POST['opcion_b'],
            'c' => $_POST['opcion_c'] ?? '',
            'd' => $_POST['opcion_d'] ?? ''
        ];
        $data['opciones'] = $opciones;
        $data['respuesta_correcta'] = $_POST['respuesta_correcta'];
    } else {
        // CORREGIDO
        $data['opciones'] = ['true' => 'Verdadero', 'false' => 'Falso'];
        $data['respuesta_correcta'] = $_POST['respuesta_vf'];
    }
    
    // USAR EL MÉTODO DE LA CLASE TEMAMANAGER
    $resultado = $temaManager->actualizarPregunta($pregunta_id, $data);
    
    if ($resultado) {
        $mensaje = "✅ Pregunta actualizada exitosamente";
        // Recargar la data de la pregunta después de la actualización exitosa
        $pregunta = $temaManager->obtenerPregunta($pregunta_id);
    } else {
        $error = "❌ Error al actualizar la pregunta";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pregunta #<?php echo $pregunta['id']; ?></title>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/mis_preguntas.css">
    <style>
        .form-editar label { font-weight: bold; margin-top: 10px; display: block; }
        .form-editar input[type="text"], .form-editar textarea, .form-editar select, .form-editar input[type="number"] { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .opciones-container { border: 1px solid #eee; padding: 15px; margin-top: 15px; border-radius: 5px; }
        .opcion-input { margin-bottom: 5px; }
        .radio-option { display: block; margin: 5px 0; }
        .form-actions { margin-top: 20px; }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="main-content">
            <header>
                <h1>✏️ Editar Pregunta #<?php echo $pregunta['id']; ?></h1>
                <p>Modifica la pregunta de tu set: <strong><?php echo htmlspecialchars($pregunta['pregunta']); ?></strong></p>
            </header>
            
            <?php if ($mensaje): ?>
                <div class="alert alert-success"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="seccion-editar">
                <form method="POST" action="" class="form-editar">
                    
                    <div class="form-group">
                        <label for="tema_id">Tema:</label>
                        <select id="tema_id" name="tema_id">
                            <?php foreach ($temas as $tema): ?>
                                <option value="<?php echo $tema['id']; ?>" 
                                    <?php echo $pregunta['tema_id'] == $tema['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($tema['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="pregunta">Texto de la Pregunta:</label>
                        <textarea id="pregunta" name="pregunta" rows="3" required><?php echo htmlspecialchars($pregunta['pregunta']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo">Tipo de pregunta:</label>
                        <select id="tipo" name="tipo" onchange="mostrarOpciones()">
                            <option value="multiple" <?php echo $pregunta['tipo'] == 'multiple' ? 'selected' : ''; ?>>Opción múltiple</option>
                            <option value="verdadero_falso" <?php echo $pregunta['tipo'] == 'verdadero_falso' ? 'selected' : ''; ?>>Verdadero/Falso</option>
                        </select>
                    </div>
                    
                    <div id="opciones_multiple" class="opciones-container" 
                         style="display: <?php echo $pregunta['tipo'] == 'multiple' ? 'block' : 'none'; ?>;">
                        <p><strong>Opciones de respuesta:</strong></p>
                        
                        <div class="form-group">
                            <label>A:</label>
                            <input type="text" name="opcion_a" class="opcion-input" 
                                   value="<?php echo htmlspecialchars($pregunta['opciones']['a'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>B:</label>
                            <input type="text" name="opcion_b" class="opcion-input" 
                                   value="<?php echo htmlspecialchars($pregunta['opciones']['b'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>C (opcional):</label>
                            <input type="text" name="opcion_c" class="opcion-input" 
                                   value="<?php echo htmlspecialchars($pregunta['opciones']['c'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>D (opcional):</label>
                            <input type="text" name="opcion_d" class="opcion-input" 
                                   value="<?php echo htmlspecialchars($pregunta['opciones']['d'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label><strong>Respuesta correcta (Selección):</strong></label>
                            <div style="margin-top: 10px;">
                                <?php $resp_m = $pregunta['respuesta_correcta']; ?>
                                <label class="radio-option"><input type="radio" name="respuesta_correcta" value="a" <?php echo $resp_m == 'a' ? 'checked' : ''; ?>> Opción A</label>
                                <label class="radio-option"><input type="radio" name="respuesta_correcta" value="b" <?php echo $resp_m == 'b' ? 'checked' : ''; ?>> Opción B</label>
                                <label class="radio-option"><input type="radio" name="respuesta_correcta" value="c" <?php echo $resp_m == 'c' ? 'checked' : ''; ?>> Opción C</label>
                                <label class="radio-option"><input type="radio" name="respuesta_correcta" value="d" <?php echo $resp_m == 'd' ? 'checked' : ''; ?>> Opción D</label>
                            </div>
                        </div>
                    </div>
                    
                    <div id="opciones_vf" class="opciones-container" 
                         style="display: <?php echo $pregunta['tipo'] == 'verdadero_falso' ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label><strong>Selecciona la respuesta correcta:</strong></label>
                            <div style="margin-top: 10px;">
                                <?php $resp_vf = $pregunta['respuesta_correcta']; ?>
                                <label style="display: block; margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 5px;">
                                    <input type="radio" name="respuesta_vf" value="true" <?php echo $resp_vf == 'true' ? 'checked' : ''; ?>> ✅ Verdadero
                                </label>
                                <label style="display: block; margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 5px;">
                                    <input type="radio" name="respuesta_vf" value="false" <?php echo $resp_vf == 'false' ? 'checked' : ''; ?>> ❌ Falso
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="puntos">Puntos:</label>
                        <input type="number" id="puntos" name="puntos" value="<?php echo $pregunta['puntos']; ?>" min="1" max="100" required>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">💾 Guardar Cambios</button>
                        <a href="mis_preguntas.php" class="btn">❌ Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function mostrarOpciones() {
        var tipo = document.getElementById('tipo').value;
        document.getElementById('opciones_multiple').style.display = tipo == 'multiple' ? 'block' : 'none';
        document.getElementById('opciones_vf').style.display = tipo == 'verdadero_falso' ? 'block' : 'none';
    }
    
    // Inicializar para asegurar que la vista es correcta al cargar
    document.addEventListener('DOMContentLoaded', mostrarOpciones);
    </script>
</body>
</html>