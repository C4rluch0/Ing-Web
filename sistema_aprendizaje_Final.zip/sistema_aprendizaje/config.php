<?php
// config.php
// Configuración general del sistema

// Mostrar errores durante desarrollo
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_aprendizaje');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', 'http://localhost/sistema_aprendizaje/');
define('UPLOAD_DIR', __DIR__ . '/avatars/');
define('PREMIOS_DIR', __DIR__ . '/premios/');
define('LOG_DIR', __DIR__ . '/logs/');

// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Autoloader mejorado
spl_autoload_register(function ($className) {
    // Directorios donde buscar las clases
    $directories = [
        __DIR__ . '/clases/',
        __DIR__ . '/classes/', // por si acaso
    ];
    
    // Posibles extensiones
    $extensions = ['.php', '.class.php'];
    
    foreach ($directories as $directory) {
        foreach ($extensions as $extension) {
            $file = $directory . $className . $extension;
            
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }
    
    // Si no se encuentra, mostrar error detallado
    $errorMsg = "Clase '$className' no encontrada. Buscada en:<br>";
    foreach ($directories as $directory) {
        $errorMsg .= "- " . $directory . $className . ".php<br>";
    }
    die($errorMsg);
});
?>